import React from 'react'
import "../App.css"
import { MdClose } from 'react-icons/md'

const Formtable = ({handleSubmit,handleOnChange,handleclose,rest}) => {
  return (
    <div className="agregarContainer">
          <form onSubmit={handleSubmit}>
          <div className="close-btn" onClick={handleclose}><MdClose/></div>
            <label htmlFor="nombre">Nombre : </label>
            <input type="text" id="nombre" name="nombre" onChange={handleOnChange} value={rest.nombre}/>
  
            <label htmlFor="correo">Correo : </label>
            <input type="email" id="correo" name="correo" onChange={handleOnChange} value={rest.correo}/>
  
            <label htmlFor="telefono">Telefono : </label>
            <input type="number" id="telefono" name="telefono" onChange={handleOnChange} value={rest.telefono}/>
  
            <button className="btn">Agregar</button>
          </form>
        </div>
  )
}

export default Formtable